KEAN CARL DONATO — PORTFOLIO WEBSITE

Files:
- index.html
- kean-photo-1.jpg
- kean-photo-2.jpg

How to use:
1. Open index.html in a browser to preview the website.
2. To publish it, upload all three files to GitHub Pages, Netlify, Vercel, or another static hosting service.
3. IMPORTANT: Your LinkedIn profile URL was not available from the information provided in this chat, so the LinkedIn button is an editable placeholder.
4. In index.html, find:
   <a class="contact-link" href="#" id="linkedinLink">
   Replace href="#" with your real LinkedIn profile URL.

Contact details already included:
Email: keandonato69@gmail.com
Viber: +63 961 967 9095
